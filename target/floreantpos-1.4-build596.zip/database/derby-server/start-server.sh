java -cp ./lib/derbynet.jar org.apache.derby.drda.NetworkServerControl start -h localhost -p 51527


